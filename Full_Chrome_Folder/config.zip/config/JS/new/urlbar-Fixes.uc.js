class FloatingUrlbar {
    /* if the urlbar is focused at the beginning of drag, blur it
 and set up an event listener for the drop */
    onDragStart(e) {
        if (document.activeElement === gURLBar.inputField) {
            gURLBar.blur();
            gBrowser.tabContainer.addEventListener("drop", this, { once: true });
        }
    }

    //once the tab is dropped, click the urlbar to restore the focus
    onDrop(e) {
        gURLBar._inputContainer.click();
    }

    //restore megabar when coming back to firefox from another application
    onActivate(e) {
        if (document.activeElement === gURLBar.inputField)
            gURLBar._inputContainer.click();
    }

    handleEvent(e) {
        switch (e.type) {
            case "dragstart":
                this.onDragStart(e);
                break;
            case "drop":
                this.onDrop(e);
                break;
            case "activate":
                this.onActivate(e);
                break;
        }
    }

    constructor() {
        gBrowser.tabContainer.addEventListener("dragstart", this);
        window.addEventListener("activate", this);
    }
}

window.floatingUrlbar = new FloatingUrlbar();